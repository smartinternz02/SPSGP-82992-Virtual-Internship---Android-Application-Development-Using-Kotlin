# Food And Grocery Delivery App

<img src="sample_ss/home.jpg" width=150/> <img src="sample_ss/merchant.jpg" width=150/> <img src="sample_ss/product.jpg" width=150/> <img src="sample_ss/checkout.jpg" width=150/>

Android application developed in Android Studio using Kotlin, Data Binding, View Binding, ViewModel, LiveData, Kotllin Coroutines, Navigation component, Firebase, Hilt together with the MVVM architecture pattern and Apollo library to fetch data from GraphQL enpoint.
