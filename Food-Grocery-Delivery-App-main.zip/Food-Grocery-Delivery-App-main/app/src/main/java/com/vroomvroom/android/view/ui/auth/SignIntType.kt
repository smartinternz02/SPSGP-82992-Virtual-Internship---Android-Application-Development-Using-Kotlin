package com.vroomvroom.android.view.ui.auth

enum class SignIntType {
    FACEBOOK,
    GOOGLE
}